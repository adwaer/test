namespace M13.InterviewProject.Domain
{
    public interface ISpellCheckError
    {
        string Word { get; }
    }
}