export const environment = {
  production: true,
  api_key: 'f5995989d4e0c4c1d30c144251cce88e'
};
