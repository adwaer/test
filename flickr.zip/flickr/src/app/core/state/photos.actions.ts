export class SetPhotoSearch {
  static readonly type = '[PHOTOS] Search';

  constructor(public payload: string) {
  }

}
